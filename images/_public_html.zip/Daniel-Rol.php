<?php
session_start();
require("./components/header.inc.php");
?>

<div id="wrapper">

    <?php include("./components/navbar.inc.php"); ?>

    <div id="main">
        <section id="one">
            <div class="inner">
                <div>
                    <a href="aboutus.php" class="button" >Back</a>
                </div>
                <header class="mb-3 d-flex justify-content-between align-items-stretch" style="border-bottom: 2px solid #212121;">
                    <div style="flex: 0.8;">
                        <h2 class="mt-3">Daniel Rol</h2>
                        <div class="contact-info mb-3">
                            <h4>Email: aliend5122002@gmail.com</h4>
                        </div>
                        <div class="portfolio-description">
                            <p>
                                Daniel Rol's journey as an artist likely brings a refreshing perspective to his work. As someone who came to art as a hobby rather than through formal training, he may approach his creative process with a sense of experimentation and freedom.
                            </p>
                            
                            <p>
                                His background in computer engineering might also influence his artistic style, perhaps incorporating elements of technology or digital artistry into his work. This blend of technical expertise and creative expression could result in artwork that is both visually captivating and intellectually stimulating.
                            </p>
                        </div>
                    </div>

                    <div class="d-flex align-items-center justify-content-center text-right">
                        <img src="images/danielRol.jpg" alt="Daniel Rol" class="rounded-circle w-100 h-auto object-fit-cover" style="max-width: 300px; max-height: 300px; min-width: 300px; min-height: 200px; border: 1px solid #212529;">
                    </div>
                </header>

                <div class="portfolio">
                    <h3>Portfolio</h3>
                    <div class="row d-flex justify-content-center" style="gap: 20px;">
                        <div class="col-md-4 col-sm-6 co-xs-12 text-center">
                            <img src="images/Daniel-Portfolio/daniel-1.png" class="img-responsive portfolio-image w-auto h-100 border border-secondary" alt="Art 1">
                        </div>
                    </div>
                </div>

            </div>
        </section>
    </div>

    <?php require("./components/footer.inc.php") ?>
</div>