<?php

define('DB_HOST', 'localhost');
define('DB_USERNAME', 'u631567875_guhitmo');
define('DB_PASSWORD', 'GuhitMo!123');
define('DB_NAME', 'u631567875_guhitmo');

$connection = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

?>